import React, { useEffect, useState } from 'react'
import './styles.css'


function Recommendations(props) {
  const [userMusic, setUserMusic] = useState(["soch na sake", "lagdi lahore di"])
  const [render,setRender] =useState(0)
  const [rating, setRating] =useState([5,6])
  const [option, setOption] =useState(1)
  const [searchQuery, setSearchQuery] = useState('');
  const [videos, setVideos] = useState([]);
  const [selectedVideoId, setSelectedVideoId] = useState(null);
  const {handleVideoClick} = props

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:8080/getr');
        if (!response.ok) {
          throw new Error('Network response was not ok.');
        }
        const data = await response.json();
        console.log("Retrieved  : ", data)
        const keysArray = data.map(obj => obj.Key);
        console.log( "HELLO ARRAY" ,keysArray)
        setUserMusic(keysArray)
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [render]); 







  useEffect(() => {
    const fetchData = async () => {
      try {
        const apiKey = process.env.REACT_APP_YOUTUBE_API_KEY;
        const requests = userMusic.map(async (query) => {
          const response = await fetch(
            `https://www.googleapis.com/youtube/v3/search?key=${apiKey}&part=snippet&q=${query}&maxResults=1`
          );
  
          if (!response.ok) {
            throw new Error('Network response was not ok.');
          }
  
          const data = await response.json();
          return data.items[0];
        });
  
        const videosData = await Promise.all(requests);
        setVideos(videosData)
        
       
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
  
      fetchData();
    
  }, [userMusic]);

  const fetchData = async () => {
    try {
      const response = await fetch('http://localhost:8080/');
      if (!response.ok) {
        throw new Error('Network response was not ok.');
      }

      alert('Recommendations Genrating....')
      
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };



  function Retrieve_Recomm(){
    setRender(!render)
  }



  return (
    <div className='background-color_ flex px-20 py-20 items-center justify-center flex-col'>
    <div className='flex flex-row justify-between items-center w-full px-24 '>
      <h1 className='text-white'>User Recommndations </h1>
      <div>
        
      <button  className='bg-blue rounded-3xl text-white hover:text-cyan-300' onClick={fetchData}>
      <span class="material-symbols-outlined">
      recommend
      </span>
      </button>
      <button className='bg-blue rounded-3xl text-white hover:text-cyan-300'  onClick={Retrieve_Recomm} ><span className="material-symbols-outlined">
      refresh
      </span></button>
      </div>
     

    </div>
    <div className='rounded-3xl px-5 py-5 flex gap-10 w-[92%] min-h-[0px] flex-row items-center justify-center flex-wrap'>
    {videos.map((video) => (
            <div className= 'w-[270px] h-[250px] mt-3 hover:scale-125 ease-in-out duration-150 cursor-pointer' key={video.id.videoId} onClick={() => handleVideoClick(video.id.videoId, video.snippet.title, video.snippet.description)}>
                <img className='rounded-xl' src={video.snippet.thumbnails.high.url} alt={video.snippet.title} />
                <h2 className='text-white'>{video.snippet.title}</h2>       
            </div>
            ))}
    </div>

    </div>
   
  )
}

export default Recommendations
