import React, { useEffect, useState } from 'react'
import './styles.css'


function UserList(props) {
  const [userMusic, setUserMusic] = useState(["soch na sake", "lagdi lahore di"])
  const [rating, setRating] =useState([5,6])
  const [option, setOption] =useState(1)
  const [searchQuery, setSearchQuery] = useState('');
  const [videos, setVideos] = useState([]);
  const [selectedVideoId, setSelectedVideoId] = useState(null);
  const [songs, setSongs] = useState([]);
  const {handleVideoClick} = props
  const [ret,setRet] =useState(0)

  function Retrive_Histroy() {
  setRet(!ret)
  }
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:8080/geth');
        if (!response.ok) {
          throw new Error('Network response was not ok.');
        }
        const data = await response.json();
        console.log("Retrieved  : ", data)
        const keysArray = data.map(obj => obj.name);
        console.log(keysArray)
        setUserMusic(keysArray)
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [ret]); 



  useEffect(() => {
    const fetchData = async () => {
      try {
        const apiKey = process.env.REACT_APP_YOUTUBE_API_KEY;
        console.log("API KEY  : : : : : ", apiKey)
        const requests = userMusic.map(async (query) => {
          const response = await fetch(
            `https://www.googleapis.com/youtube/v3/search?key=${apiKey}&part=snippet&q=${query}&maxResults=1`
          );
  
          if (!response.ok) {
            throw new Error('Network response was not ok.');
          }
  
          const data = await response.json();
          return data.items[0];
        });
  
        const videosData = await Promise.all(requests);
        const arr =findUniqueByETag(videosData)
        console.log("Arr", arr)
        if(!hasDuplicates(arr))  {
        setVideos(arr)
        }
       
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
  
    fetchData();
    
  }, [userMusic]);

  function findUniqueByETag(elements) {
    const uniqueMap = new Map();
    
    // Filter out duplicates based on 'etag'
    elements.forEach(element => {
      if (!uniqueMap.has(element.etag)) {
        uniqueMap.set(element.etag, element);
      }
    });
    
    // Extract the unique elements from the Map
    const uniqueArray = Array.from(uniqueMap.values());
    
    return uniqueArray;
  }
  
  function hasDuplicates(arr) {
    return new Set(arr).size !== arr.length ? 1 : 0;
  }
  


  return (
    <div className='background-color_ flex px-20 py-20 items-center justify-center flex-col'>
    <div className='flex flex-row justify-between items-center w-full px-24 '>
      <h1 className='text-white'>User Favorites </h1>
      <button className='bg-blue rounded-3xl text-white hover:text-cyan-300'  onClick={Retrive_Histroy}><span className="material-symbols-outlined">
refresh
</span></button>

    </div>
    <div className='rounded-3xl px-5 py-5 flex gap-10 w-[92%] min-h-[0px] flex-row items-center justify-center flex-wrap'>
    {videos.map((video) => (
            <div className= 'w-[270px] h-[250px] mt-3 hover:scale-125 ease-in-out duration-150  cursor-pointer' key={video.id.videoId} onClick={() => handleVideoClick(video.id.videoId, video.snippet.title, video.snippet.description)}>
                <img className='rounded-xl' src={video.snippet.thumbnails.high.url} alt={video.snippet.title} />
                <h2 className='text-white'>{video.snippet.title}</h2>       
            </div>
            ))}
    </div>

    </div>
   
  )
}

export default UserList
