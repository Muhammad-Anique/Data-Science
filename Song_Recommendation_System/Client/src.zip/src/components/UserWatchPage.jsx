import React, { useEffect, useState } from 'react';
import VideoPlay from './VideoPlay'; // Assuming the path to your VideoPlay component
import './styles.css'
import names from './names.js';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/joy/Autocomplete';


function UserWatchPage(props) {
  const {title , desc, handleVideoClick, option , selectedVideoId, setOption} = props
  const [searchQuery, setSearchQuery] = useState('Tajdar-e-Haram');
  const [videos, setVideos] = useState([]);



  const handleInputChange = (event) => {
    setSearchQuery(event.target.value);
  };
 

  async function search(){
    setOption(1)
    try {
      const apiKey =  process.env.REACT_APP_YOUTUBE_API_KEY;
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?key=${apiKey}&part=snippet&q=${searchQuery}`
      );

      if (!response.ok) {
        throw new Error('Network response was not ok.');
      }

      const data = await response.json();
      setVideos(data.items);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }


  useEffect(() => {
    const searchVideos = async () => {
      try {
        const apiKey = process.env.REACT_APP_YOUTUBE_API_KEY;
        const response = await fetch(
          `https://www.googleapis.com/youtube/v3/search?key=${apiKey}&part=snippet&q=${searchQuery}`
        );
  
        if (!response.ok) {
          throw new Error('Network response was not ok.');
        }
  
        const data = await response.json();
        setVideos(data.items);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
  
    // Assuming searchQuery is defined elsewhere or passed as a prop
    searchVideos();
  }, [option]); // Make sure to include searchQuery in the dependencies array if it's used inside useEffect
  


  return (
    <div className='flex flex-col justify-center items-center min-h-screen w-full background-color_  gap-7 p-20'>
      <div className='w-[50%] dark-grey h-[55px] rounded-3xl flex flex-row items-center justify-center gap-3 px-2 bg-grey-300'>   
        <input type="text" value={searchQuery} onChange={handleInputChange} className='px-2 py-1 text-white focus:border-none active:border-none  w-[90%] bg-transparent' />      
        <button className='text-white' onClick={search}><span className="material-symbols-outlined">
            search
        </span>
        </button>
      </div>
        {
            option===1 ? (<div className='rounded-3xl px-5 py-5 flex gap-10 w-[92%] min-h-[0px] flex-row items-center flex-wrap'>
            {videos.map((video) => (
            <div className= 'w-[270px] h-[250px] mt-3 hover:scale-125 ease-in-out duration-150 cursor-pointer' key={video.id.videoId} onClick={() => handleVideoClick(video.id.videoId, video.snippet.title, video.snippet.description)}>
                <img className='rounded-xl' src={video.snippet.thumbnails.high.url} alt={video.snippet.title} />
                <h2 className='text-white'>{video.snippet.title}</h2>       
            </div>
            ))}
        </div>):  ( <VideoPlay videoId={selectedVideoId} title={title} song_name={searchQuery} description={desc}/>)
        }
    
    </div>
  );
}
//  { Render VideoPlay component if a video is selected */}
//  {selectedVideoId && (
//     <VideoPlay videoId={selectedVideoId} title="" description="" />
//   )}
export default UserWatchPage;
