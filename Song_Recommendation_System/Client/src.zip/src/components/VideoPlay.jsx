import React, { useState } from 'react';
import './styles.css'
import Box from '@mui/material/Box';
import Rating from '@mui/material/Rating';
import Typography from '@mui/material/Typography';
function VideoPlay(props) {
  const { videoId, title, description, song_name } = props;

 
  const [value, setValue] = useState(0);


  const handleAddToList = () => {
    const dataToSend = {
      name: song_name, // Replace 'SongName' with the actual song name
      rating: value, // Replace '5' with the actual rating
    };

    console.log("Data sending", dataToSend)

    fetch('http://localhost:8080/post', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(dataToSend),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        console.log('Data added successfully:', data);
        alert('Song Added')
      })
      .catch((error) => {
        console.error('Error adding data:', error);
        alert('Error')
      });
  };
  return (
    <div className="mx-auto px-10 mt-8 flex flex-row">
      <div className="aspect-w-16 aspect-h-9 -translate-x-12 ">
        <iframe
          title={title}
          className='w-[800px] h-[400px] '
          src={`https://www.youtube.com/embed/${videoId}`}
          allowFullScreen
        ></iframe>
      </div>
      <div className='flex flex-col'>

      <h2 className="text-2xl  text-gray-50 font-bold mt-4">{title}</h2>
      <p className="text-gray-300 mt-5">{description}</p>
      <Box
      sx={{
        '& > legend': { mt: 2 },
      }}
    >
      <div className='w-[200px] h-[80px] dark-grey px-2 py-2 flex flex-col items-center justify-center rounded-3xl mt-5'>
      <Typography className="text-white" component="legend">Rate the Music</Typography>
      <Rating

        name="simple-controlled"
        value={value}
        onChange={(event, newValue) => {
          setValue(newValue);
        }}
      />
      </div>
      
    </Box>
      <button className='text-white mt-5 dark-grey w-[200px]  rounded-3xl px-10 py-2 hover:bg-cyan-500 hover:text-black' onClick={handleAddToList}>Add to list</button>
      </div>
      
    </div>
  );
}

export default VideoPlay;
