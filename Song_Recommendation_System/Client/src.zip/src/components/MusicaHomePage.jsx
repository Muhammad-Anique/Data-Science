import React from 'react'
import '../App.css';
import video from  '../assets/bgvid.mp4'
import musica_vid from '../assets/spinner.mp4'
import  { useRef, useEffect } from 'react';
import music from '../assets/musicl.png'
function MusicaHomePage() {
  const videoRef = useRef(null);
  useEffect(() => {
    const video = videoRef.current;

    const loopStart = 5; // Start time of the loop (in seconds)
    const loopEnd = 40; // End time of the loop (in seconds)

    const checkTime = () => {
      if (video.currentTime >= loopEnd) {
        video.currentTime = loopStart;
      }
    };

    const interval = setInterval(checkTime, 100); // Check current time every 100 milliseconds

    return () => clearInterval(interval); // Cleanup on unmount

  }, []);

  return (
  
    <>
     <div className='flex flex-col h-full w-full items-center relative justify-center'>
     <img src={music} className='z-10 absolute w-[160px] h-[160px] right-350' alt="" />
     <div className="video-wrapper box circle relative">
      <video  autoPlay loop muted className="w-full c  h-auto">
        <source src={musica_vid} type="video/mp4" />
      </video>
      <div className="darken-overlay absolute top-0 left-0 w-full h-full"></div>
    </div>

      </div>
      <video ref={videoRef} autoPlay loop muted className="background-video ">
      <source src={video} type="video/mp4" />
      Your browser does not support the video tag.
      </video>
    </>
     
 
  )
}

export default MusicaHomePage
