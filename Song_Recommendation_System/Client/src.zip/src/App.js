import './App.css';
import MusicaHomePage from './components/MusicaHomePage';
import UserWatchPage from './components/UserWatchPage';
import UserList from './components/UserList';
import Recommendations from './components/Recommendations';
import { useState } from 'react';

function App() {
  const [title, setTittle] =useState('')
  const [desc,setDesc]=useState('')
  const [selectedVideoId, setSelectedVideoId] = useState(null);  
  const [option, setOption] =useState(1)

  const handleVideoClick = (videoId,tittle, description) => {
    setOption(0)
    setSelectedVideoId(videoId);
    setTittle(tittle)
    setDesc(description)
  };
   

  return (
    <>
      <div className='h-screen w-screen overflow-y-auto'>
      <MusicaHomePage/>
      <UserWatchPage title={title} desc={desc} handleVideoClick={handleVideoClick} option={option} selectedVideoId={selectedVideoId} setOption={setOption} />
      <UserList handleVideoClick={handleVideoClick}/>
      <Recommendations handleVideoClick={handleVideoClick}/>
      </div>
  
    </>
   
   
  );
}

export default App;
